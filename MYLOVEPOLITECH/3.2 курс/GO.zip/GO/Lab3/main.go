package main

import (
	rand "Lab3/packages"
	"fmt"
	"math"
)

func main() {
	//Варіант 19.
	var K = 10000
	var A = 1140671485
	var C = 12820163 
	var M = math.Pow(2, 24) 
	var Min = 0
	var Max = 99

	var x float64
	var arr = make([]int64, K)
	rand.LineRand(K, A, C, M, Min, Max, x, arr, 0)

	fmt.Printf(rand.Print(arr, 19))

	fmt.Printf("Number frequency:\n")
	rand.Frequency(K, Max, arr, 10)

	fmt.Printf("Statistical probability: \n")
	var probability = rand.StatisticProbability(K, Max, arr, 10)

	var expectation = rand.Expectation(K, arr, probability)
	fmt.Printf("Mathematical expectation - %f\n", expectation)

	var dispersion = rand.Dispersion(K, arr, expectation, probability)
	fmt.Printf("Dispersion - %f\n", dispersion)

	var deviation = rand.Deviation(dispersion)
	fmt.Printf("Mean square deviation - %f\n", deviation)
}
