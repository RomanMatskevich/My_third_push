package rand

import (
	"fmt"
	"math"
	"strconv"
)

func LineRand(K int, A int, C int, M float64, Min int, Max int, x float64, arr []int64, k int) {
	if k < K {
		x = math.Mod(float64(A)*x+float64(C), M)
		k++
		LineRand(K, A, C, M, Min, Max, x, arr, k)
		arr[k-1] = (int64)(float64(Min) + math.Mod(x, float64(Max+1-Min)))
	}
	return
}

func Print(arr []int64, count int64) string {
	var str string = "Arr = ["
	for i := 1; i < int(count); i++ {
		str += strconv.Itoa((int)(arr[i]))
		if i != int(count)-1 {
			str += ", "
		}
	}
	str += "]"
	return str
}

func Frequency(K int, Max int, arr []int64, lines int) {
	var k int
	for i := 0; i <= Max; i++ {
		k = 0
		for j := 0; j < int(K); j++ {
			if int64(i) == arr[j] {
				k++
			}
		}
		fmt.Printf("%d meets %d times, probability - %f\n", i, k, float64(k)/float64(K))
		if i > lines {
			break
		}
	}
}

func StatisticProbability(K int, Max int, arr []int64, lines int) []float64 {

	var k int
	var P = make([]float64, K)
	for i := 0; i <= Max; i++ {
		k = 0
		for j := 0; j < K; j++ {
			if int64(i) == arr[j] {
				k++
			}
		}
		P[i] = float64(k) / float64(K)
		if i <= lines {
			fmt.Printf("The statistical probability of a number %d - %f \n", i, P[i])
		}
	}
	return P
}

func Expectation(K int, arr []int64, P []float64) float64 {
	var M float64 = 0

	for i := 0; i < K; i++ {
		M += float64(arr[i]) * P[i]
	}
	return M
}

func Dispersion(K int, arr []int64, M float64, P []float64) float64 {
	var D float64 = 0

	for i := 0; i < K; i++ {
		D += math.Pow(float64(arr[i])-M, 2) * P[i]
	}
	return D
}

func Deviation(D float64) float64 {
	return math.Sqrt(D)
}
