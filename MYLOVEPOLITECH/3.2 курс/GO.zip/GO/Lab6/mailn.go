package main

import (
	console "Lab6/packages"
	data "Lab6/packages/structs"
)

func main() {
	isBankCreated := false
	bank := data.Bank{}
	ch := make(chan struct{}, 1)

	console.Console(ch, isBankCreated, bank)
}
