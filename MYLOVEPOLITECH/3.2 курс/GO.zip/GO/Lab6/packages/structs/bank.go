package structs

import "fmt"

type Bank struct {
	Name      string
	BankMoney float64
	Deposits  float64
	Credits   float64
	Clients   []*Client
}

func NewBank(_name string, _money float64) Bank {
	return Bank{_name, _money, 0, 0, []*Client{}}
}
func (_bank *Bank) SetName(_name string) {
	_bank.Name = _name
}

func (_bank *Bank) SetBankMoney(_money float64) {
	_bank.BankMoney = _money
}

func (_bank *Bank) SetDeposit(_deposit float64) {
	_bank.Deposits = _deposit
}
func (_bank *Bank) GetDeposit() float64 {
	return _bank.Deposits
}

func (_bank *Bank) SetCredit(_credit float64) {
	_bank.Credits = _credit
}
func (_bank *Bank) GetBankMoney() float64 {
	return _bank.BankMoney
}
func (_bank *Bank) GetClient(_index int) *Client {
	return _bank.Clients[_index]
}

func (_bank *Bank) GetClientByAccountNumber(_accNum string) {
	for _, c := range _bank.Clients {
		if c.AccountNumber == _accNum {
			c.PrintClientInfo()
		}
	}
}
func (_bank *Bank) GetClientBySurname(_surname string) {
	for _, c := range _bank.Clients {
		if c.Surname == _surname {
			c.PrintClientInfo()
		}
	}
}
func (_bank *Bank) AddClient(_client *Client) {
	_bank.Clients = append(_bank.Clients, _client)
	_bank.AddToDeposit(_client.сDeposit)
	_bank.AddToCredit(-_client.сCredit)
	_client.Bank = _bank
}
func (_bank *Bank) RemoveClient(_index int) {
	_bank.Clients = append(_bank.Clients[:_index], _bank.Clients[_index+1:]...)
}
func (_bank *Bank) PrintClients() {
	fmt.Printf("%-10s %-10s %-10s %-10s\n", "Bank", "Deposits", "Credits", "Bank money")
	fmt.Printf("%-10s %-10.2f %-10.2f %-10.2f\n", _bank.Name, _bank.Deposits, _bank.Credits, _bank.BankMoney)
	fmt.Printf("%-30s %s\n", "Client", "Account number")
	for _, c := range _bank.Clients {
		c.PrintClientInfo()
	}
}
func (_bank *Bank) AddToDeposit(_deposit float64) {
	_bank.Deposits = _bank.Deposits + _deposit
}
func (_bank *Bank) SubFromDeposit(_deposit float64) {
	_bank.Deposits -= _deposit
}
func (_bank *Bank) AddToCredit(_credit float64) {
	_bank.Credits += _credit
	_bank.TakeMoney(_credit)
}
func (_bank *Bank) SubFromCredit(_credit float64) {
	_bank.Credits -= _credit
	_bank.AddMoney(_credit)
}
func (_bank *Bank) AddMoney(_money float64) {
	_bank.BankMoney += _money
}
func (_bank *Bank) TakeMoney(_money float64) {
	_bank.BankMoney -= _money
}
func (_bank *Bank) CheckMoney(_money float64) bool {
	if _bank.GetBankMoney() < _money {
		return false
	}
	return true
}
