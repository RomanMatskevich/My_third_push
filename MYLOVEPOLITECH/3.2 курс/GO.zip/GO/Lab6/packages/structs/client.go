package structs

import "fmt"

type Client struct {
	Name          string
	Surname       string
	AccountNumber string
	сDeposit      float64
	сCredit       float64
	Bank          *Bank
}

func NewClient(_name string, _surname string, _accNum string, _deposit float64, _credits float64) Client {
	return Client{_name, _surname, _accNum, _deposit, _credits, nil}
}
func (_client *Client) SetName(_name string) {
	_client.Name = _name
}
func (_client *Client) GetName() string {
	return _client.Name
}

func (_client *Client) SetSurName(_surname string) {
	_client.Surname = _surname
}
func (_client *Client) GetSurName() string {
	return _client.Surname
}

func (_client *Client) SetDeposit(_deposit float64) {
	_client.сDeposit = _deposit
}
func (_client *Client) GetFullName() string {
	return _client.Name + " " + _client.Surname
}
func (_client *Client) GetDeposit() float64 {
	return _client.сDeposit
}

func (_client *Client) AddToDeposit(_sum float64) {
	_client.сDeposit += _sum
	_client.Bank.AddToDeposit(_sum)
}
func (_client *Client) SubFromDeposit(_sum float64) {
	_client.сDeposit -= _sum
	_client.Bank.SubFromDeposit(_sum)
}
func (_client *Client) SetCredit(c float64) {
	_client.сCredit = c
}
func (_client *Client) GetCredit() float64 {
	return _client.сCredit
}


func (_client *Client) AddToCredit(c float64) {
	_client.сCredit -= c
	_client.Bank.AddToCredit(c)
}
func (_client *Client) SubFromCredit(c float64) {
	_client.сCredit += c
	_client.Bank.SubFromCredit(c)
}


func (_client *Client) PrintClientInfo() {
	fmt.Printf("%-10s %-10.2f %-10.2f %-10s\n", _client.GetFullName(), _client.сDeposit, _client.сCredit, _client.AccountNumber)
}

func (_client *Client) TakeFromDeposit(money float64) {
	if !_client.CheckMoney(money) {
		return
	}
	_client.SubFromDeposit(money)
}
func (_client *Client) PayCredit(money float64) {
	if money < 0 {
		return
	}
	if !_client.CheckMoney(money) {
		return
	}
	if money > -_client.GetCredit() {
		extra := money + _client.GetCredit()
		money -= extra
	}
	_client.SubFromDeposit(money)
	_client.SubFromCredit(money)
}
func (_client *Client) TakeCredit(money float64) {
	if !_client.Bank.CheckMoney(money) {
		return
	}
	_client.AddToDeposit(money)
	_client.AddToCredit(money)
}
func (_client *Client) CheckMoney(m float64) bool {
	if _client.GetDeposit() < m {
		fmt.Printf("%s, you don't have enough money: %.3f\n", _client.GetFullName(), m)
		fmt.Printf("You have: %.3f\n", _client.GetDeposit())
		return false
	}
	return true
}
