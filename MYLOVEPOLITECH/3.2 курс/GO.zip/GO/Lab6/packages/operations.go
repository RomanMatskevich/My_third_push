package packages

import (
	data "Lab6/packages/structs"
	"fmt"
	"math/rand"
	"strconv"
	"time"
)

func ClientDepositWork(client *data.Client, ch chan struct{}) {
	for client.GetDeposit() > 0 {
		choice := rand.Intn(2) + 1
		<-ch
		if choice == 1 {
			client.AddToDeposit(100)
		} else {
			client.TakeFromDeposit(100)
		}
		ch <- struct{}{}
		time.Sleep(time.Second)
	}
	fmt.Println(client.GetFullName() + " work with deposits completed\n")
}
func ClientCreditWork(client *data.Client, ch chan struct{}) {
	for client.GetCredit() < 0 {
		choice := rand.Intn(2) + 1
		<-ch
		if choice == 1 {
			client.TakeCredit(100)
		} else {
			client.PayCredit(100)
		}
		ch <- struct{}{}
		time.Sleep(time.Second)
	}
	fmt.Println(client.GetFullName() + " work with credits completed\n")
}

func Console(ch chan struct{}, isBankCreated bool, bank data.Bank) {
	go func() {
		ch <- struct{}{}
	}()
	for true {
		var choice int
		var tmp string
		var err error
		fmt.Println("1: Create bank\n2: Add client for credits\n3: Add client for deposits")
		fmt.Println("4: Get user info by account number")
		fmt.Println("5: Get user info by surname")
		fmt.Println("6: Get all users info")
		fmt.Println("0: Exit")
		for true {
			fmt.Print("-> ")
			_, _ = fmt.Scanln(&tmp)
			choice, err = strconv.Atoi(tmp)
			if err != nil || choice < 0 || choice > 6 {
				fmt.Println("Incorrect input!!!")
			} else {
				break
			}
		}
		if !isBankCreated && choice != 1 {
			fmt.Println("First add the bank")
			continue
		}
		switch choice {
		case 0:
			return
		case 1:
			{
				if isBankCreated {
					fmt.Printf("The bank has already been created: %s\n", bank.Name)
					break
				}
				var (
					bankName  string
					bankMoney float64
				)
				fmt.Print("Bank name: ")
				_, _ = fmt.Scanln(&bankName)
				for bankName == "" {
					fmt.Println("Incorrect input, try again: ")
					_, _ = fmt.Scanln(&bankName)
				}
				for true {
					fmt.Print("Bank money:  ")
					_, _ = fmt.Scanln(&tmp)
					bankMoney, err = strconv.ParseFloat(tmp, 64)
					if err != nil || bankMoney <= 0 {
						fmt.Println("Incorrect input, try again: ")
					} else {
						break
					}
				}
				bank = data.NewBank(bankName, bankMoney)
				isBankCreated = true
			}
		case 2, 3:
			{
				var (
					name    string
					surname string
					accNum  string
				)
				fmt.Print("Client name ")
				_, _ = fmt.Scanln(&name)
				for name == "" {
					fmt.Println("Incorrect input, try again: ")
					_, _ = fmt.Scanln(&name)
				}
				fmt.Print("Client surname: ")
				_, _ = fmt.Scanln(&surname)
				for surname == "" {
					fmt.Println("Incorrect input, try again: ")
					_, _ = fmt.Scanln(&surname)
				}
				fmt.Print("Client account number: ")
				_, _ = fmt.Scanln(&accNum)
				for accNum == "" {
					fmt.Println("Incorrect input, try again: ")
					_, _ = fmt.Scanln(&accNum)
				}
				if choice == 2 {
					client := data.NewClient(name, surname, accNum, 500, -500)
					go func() {
						<-ch
						bank.AddClient(&client)
						ch <- struct{}{}
						go ClientCreditWork(&client, ch)
					}()
				} else {
					client := data.NewClient(name, surname, accNum, 500, -10)
					go func() {
						<-ch
						bank.AddClient(&client)
						ch <- struct{}{}
						go ClientDepositWork(&client, ch)
					}()
				}
			}
		case 4:
			{
				accNum := ""
				fmt.Print("Account number: ")
				fmt.Scanln(&accNum)
				go func() {
					<-ch
					bank.GetClientByAccountNumber(accNum)
					ch <- struct{}{}
				}()
			}
		case 5:
			{
				surname := ""
				fmt.Print("Surname: ")
				fmt.Scanln(&surname)
				go func() {
					<-ch
					bank.GetClientBySurname(surname)
					ch <- struct{}{}
				}()
			}
		case 6:
			{
				go func() {
					<-ch
					bank.PrintClients()
					ch <- struct{}{}
				}()
			}
		}
	}
}
