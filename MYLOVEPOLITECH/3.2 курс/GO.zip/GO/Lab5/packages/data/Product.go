package data

import "fmt"

type Product struct {
	name     string
	price    float64
	cost     Currency
	quantity int64
	producer string
	weight   float64
}

func ProductDefaultConstructor() *Product {
	product := new(Product)
	product.name = "Table lamp"
	product.price = 2.34
	product.cost = Currency{name: "USD", exRate: 28.8}
	product.quantity = 1000
	product.producer = "China"
	product.weight = 345

	return product
}

func ProductConstructor(_name string, _price float64, _cost Currency, _quantity int64, _producer string, _weight float64) *Product {
	product := new(Product)
	product.name = _name
	product.price = _price
	product.cost = _cost
	product.quantity = _quantity
	product.producer = _producer
	product.weight = _weight

	return product
}

func (product *Product) GetName() string {
	return product.name
}
func (product *Product) SetName(_name string) {
	product.name = _name
}

func (product *Product) GetPrice() float64 {
	return product.price
}
func (product *Product) SetPrice(_price float64) {
	product.price = _price
}

func (product *Product) GetCost() Currency {
	return product.cost
}
func (product *Product) SetCost(_cost Currency) {
	product.cost = _cost
}

func (product *Product) GetQuantity() int64 {
	return product.quantity
}
func (product *Product) SetQuantity(_quantity int64) {
	product.quantity = _quantity
}

func (product *Product) GetProducer() string {
	return product.producer
}
func (product *Product) SetProducer(_producer string) {
	product.producer = _producer
}

func (product *Product) GetWeight() float64 {
	return product.weight
}
func (product *Product) SetWeight(_weight float64) {
	product.weight = _weight
}

func (product *Product) GetPriceIn() float64 {
	return product.GetPrice() * product.cost.GetExRate()
}
func (product *Product) GetTotalPrice() float64 {
	return (product.GetPrice() * product.cost.GetExRate()) * float64(product.GetQuantity())
}
func (product *Product) GetTotalWeight() float64 {
	return float64(product.GetQuantity()) * product.GetWeight()
}

func (product *Product) Show() string {

	result := "Name: " + product.GetName() + "\n"
	result += "Quantity: " + fmt.Sprintf("%d", product.GetQuantity()) + "\n"
	result += "Producer: " + product.GetProducer() + "\n"
	result += "Weight: " + fmt.Sprintf("%.2f", product.GetWeight()) + "\n"
	result += "Price: " + fmt.Sprintf("%.2f ", product.GetPrice()) + product.cost.GetName() + " - " + fmt.Sprintf("(%.2f) UAH", product.GetPriceIn()) + "\n"
	result += "Currency: " + product.cost.Show() + "\n"

	return result
}
