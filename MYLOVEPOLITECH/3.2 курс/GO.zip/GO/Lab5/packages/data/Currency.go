package data

import "fmt"

type Currency struct {
	name   string
	exRate float64
}

func CurrencyDefaultConstructor() *Currency {
	currency := new(Currency)
	currency.name = "USD"
	currency.exRate = 28.8

	return currency
}

func CurrencyConstructor(_name string, _exRate float64) *Currency {
	currency := new(Currency)
	currency.name = _name
	currency.exRate = _exRate
	return currency
}

func (currency *Currency) GetName() string {
	return currency.name
}
func (currency *Currency) SetName(_name string) {
	currency.name = _name
}

func (currency *Currency) GetExRate() float64 {
	return currency.exRate
}
func (currency *Currency) SetExRate(_eaRate float64) {
	currency.exRate = _eaRate
}

func (currency *Currency) Show() string {
	result := "Name: " + currency.GetName() + "\n"
	result += "ExRate: " + fmt.Sprintf("%.2f", currency.GetExRate())
	return result
}
