package packages

import (
	"Lab5/packages/data"
	"errors"
	"fmt"
	"os"
)

func ReadProductsArray() ([]data.Product, error) {
	var products []data.Product

	size := 0
	fmt.Print("Enter the number of products: ")
	_, err := fmt.Fscan(os.Stdin, &size)

	if err != nil {
		return nil, errors.New("incorrect array length value")
	}

	for i := 0; i < size; i++ {
		fmt.Println("\nFilling in information about the product №", i+1, "...")
		item := readProduct()
		products = append(products, *item)
	}

	return products, nil
}

func readProduct() *data.Product {
	fmt.Println("Create product: " +
		"\n 1) Own product" +
		"\n 2) By default")

	var constructorType int64
	_, err := fmt.Fscan(os.Stdin, &constructorType)

	var (
		name     string
		price    float64
		cost     *data.Currency
		quantity int64
		producer string
		weight   float64
	)

	switch constructorType {
	case 1:
		fmt.Print("Name: ")
		_, err = fmt.Fscan(os.Stdin, &name)

		fmt.Print("Price: ")
		_, err = fmt.Fscan(os.Stdin, &price)

		fmt.Print("Quantity: ")
		_, err = fmt.Fscan(os.Stdin, &quantity)

		fmt.Print("Producer: ")
		_, err = fmt.Fscan(os.Stdin, &producer)

		fmt.Print("Weight: ")
		_, err = fmt.Fscan(os.Stdin, &weight)

		cost = readCurrency()

		if err != nil {
			fmt.Println("Typing error! A default product has been created.")
			return data.ProductDefaultConstructor()
		}

		return data.ProductConstructor(name, price, *cost, quantity, producer, weight)
	case 2:
		return data.ProductDefaultConstructor()
	default:
		fmt.Println("Error! Incorrect option, product has been created by default.")
		return data.ProductDefaultConstructor()
	}
}

func readCurrency() *data.Currency {
	fmt.Println("Create currency: " +
		"\n 1) Own currency" +
		"\n 2) By default")

	var constructorType int64
	_, err := fmt.Fscan(os.Stdin, &constructorType)

	var (
		name   string
		exRate float64
	)
	switch constructorType {
	case 1:
		fmt.Print("Name: ")
		_, err = fmt.Fscan(os.Stdin, &name)

		fmt.Print("Exchange rate: ")
		_, err = fmt.Fscan(os.Stdin, &exRate)

		if err != nil {
			fmt.Println("Typing error! A default currency has been created.")
			return data.CurrencyDefaultConstructor()
		}

		return data.CurrencyConstructor(name, exRate)
	case 2:
		return data.CurrencyDefaultConstructor()
	default:
		fmt.Println("Error! Incorrect option, currency has been created by default.")
		return data.CurrencyDefaultConstructor()
	}
}

func PrintProducts(products []data.Product) {
	for index, item := range products {
		fmt.Println("Product №", index+1)
		PrintProduct(item)
	}
}

func PrintProduct(product data.Product) {
	fmt.Println(product.Show())
}

func GetProductsInfo(products []data.Product) (mostExpensive data.Product, cheapest data.Product) {
	mostExpensive = products[0]
	cheapest = products[0]

	for i := 1; i < len(products); i++ {
		if products[i].GetPrice() < cheapest.GetPrice() {
			cheapest = products[i]
		} else if products[i].GetPrice() > mostExpensive.GetPrice() {
			mostExpensive = products[i]
		}
	}
	return mostExpensive, cheapest
}
