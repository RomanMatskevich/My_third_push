package main

import (
	data "Lab5/packages"
	"fmt"
)

func main() {
	products, _ := data.ReadProductsArray()

	data.PrintProducts(products)

	mostExpensive, cheapest := data.GetProductsInfo(products)
	fmt.Println("Most expensive - \n", mostExpensive.Show())
	fmt.Println("Cheapest- \n", cheapest.Show())

	fmt.Println("The total cost of the most expensive product - ", fmt.Sprintf("%.2f", mostExpensive.GetTotalPrice()))
	fmt.Println("The total weight of the most expensive product - ", fmt.Sprintf("%.2f", mostExpensive.GetTotalWeight()))
}
