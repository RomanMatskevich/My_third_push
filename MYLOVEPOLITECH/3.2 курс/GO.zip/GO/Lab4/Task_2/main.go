package main

import (
	functions "Lab4/Task_2/packages"
	"github.com/andlabs/ui"
	_ "github.com/andlabs/ui/winmanifest"
)

func main() {
	err := ui.Main(functions.InitGUI)
	if err != nil {
		panic(err)
	}
}
