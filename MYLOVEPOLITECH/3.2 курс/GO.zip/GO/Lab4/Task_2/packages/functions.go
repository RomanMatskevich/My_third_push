package functions

/*
#include<stdio.h>
#include<stdbool.h>
float CalculatePrice(int days, int countyID, int seasonID, bool isIndividualGuide, bool isDeluxeRoom)
{
	float cost = 0;
	switch (countyID)
	{
		case 0:
		{
			cost = (seasonID == 0) ? 150: 100;
			break;
		}
		case 1:
		{
			cost = (seasonID == 0) ? 200: 160;
			break;
		}
		case 2:
		{
			cost = (seasonID == 0) ? 180: 120;
			break;
		}
	}

	float price = days * cost;

	if (isIndividualGuide)
		price += days * 50;
	if (isDeluxeRoom)
		price *= 1.2;
	return price;
}
*/
import "C"

import (
	"fmt"
	"github.com/andlabs/ui"
	"strconv"
)

func CalculatePriceWithGo(days *ui.Entry, country *ui.Combobox, season *ui.Combobox, individualGuide *ui.Checkbox, deluxeRoom *ui.Checkbox) float64 {
	var _days float64 = 0
	if num, err := strconv.ParseFloat(days.Text(), 64); err == nil {
		_days = num
	}

	var _country = country.Selected()
	var _season = season.Selected()

	var _individualGuide = individualGuide.Checked()
	var _deluxeRoom = deluxeRoom.Checked()

	var cost float64 = 0.0

	switch int(_country) {
	case 0:
		if float64(_season) == 0 {
			cost = 150
		}
		if float64(_season) == 1 {
			cost = 100
		}
	case 1:
		if float64(_season) == 0 {
			cost = 200
		}
		if float64(_season) == 1 {
			cost = 160
		}
	case 2:
		if float64(_season) == 0 {
			cost = 180
		}
		if float64(_season) == 1 {
			cost = 120
		}
	}
	var price float64 = _days * cost
	if bool(_individualGuide) {
		price += _days * 50
	}
	if bool(_deluxeRoom) {
		price *= 1.2
	}
	return price
}

func CalculatePriceWithC(days *ui.Entry, country *ui.Combobox, season *ui.Combobox, individualGuide *ui.Checkbox, deluxeRoom *ui.Checkbox) float64 {
	var _days int64 = 0
	if num, err := strconv.ParseInt(days.Text(), 0, 64); err == nil {
		_days = num
	}

	var _country = country.Selected()
	var _season = season.Selected()

	var _individualGuide = individualGuide.Checked()
	var _deluxeRoom = deluxeRoom.Checked()

	return (float64)(C.CalculatePrice(C.int(_days), C.int(_country), C.int(_season), C.bool(_individualGuide), C.bool(_deluxeRoom)))
}

func InitGUI() {
	window := ui.NewWindow("Калькулятор", 300, 200, false)
	window.SetMargined(true)

	windowContainer := ui.NewVerticalBox()
	windowContainer.SetPadded(true)

	inputsContainer := ui.NewHorizontalBox()
	inputsContainer.SetPadded(true)

	//----------
	countryAndTourDurationGroup := ui.NewGroup("Тур")
	countryAndTourDurationGroup.SetMargined(true)

	cityAndTourDurationForm := ui.NewForm()
	cityAndTourDurationForm.SetPadded(true)

	_countriesComboBox := ui.NewCombobox()
	_countriesComboBox.Append("Болгарія")  //0
	_countriesComboBox.Append("Німеччина") //1
	_countriesComboBox.Append("Польща")    //2

	cityAndTourDurationForm.Append("Країна", _countriesComboBox, false)

	_days := ui.NewEntry()
	cityAndTourDurationForm.Append("Днів - ", _days, false)

	countryAndTourDurationGroup.SetChild(cityAndTourDurationForm)
	//^^^^

	//----------
	seasonGroup := ui.NewGroup("Сезон")
	seasonGroup.SetMargined(true)

	seasonBox := ui.NewVerticalBox()
	seasonBox.SetPadded(true)

	_seasonComboBox := ui.NewCombobox()
	_seasonComboBox.Append("Зима") //0
	_seasonComboBox.Append("Літо") //1

	seasonBox.Append(_seasonComboBox, false)

	_individualGuideCheckBox := ui.NewCheckbox("Індивідуальний гід")
	seasonBox.Append(_individualGuideCheckBox, false)
	_deluxeRoomCheckBox := ui.NewCheckbox("Проживання в номері люкс")
	seasonBox.Append(_deluxeRoomCheckBox, false)

	seasonGroup.SetChild(seasonBox)
	//^^^^

	//----------
	inputsContainer.Append(countryAndTourDurationGroup, false)
	inputsContainer.Append(seasonGroup, false)

	windowContainer.Append(inputsContainer, false)
	//^^^^

	//----------
	totalBillBox := ui.NewVerticalBox()
	totalBillBox.SetPadded(true)

	calculateButton := ui.NewButton("Розрахувати")
	totalBillBox.Append(calculateButton, false)

	totalBillLabel := ui.NewLabel("00.00 $")
	totalBillBox.Append(totalBillLabel, false)
	//^^^^

	windowContainer.Append(totalBillBox, true)
	window.SetChild(windowContainer)

	calculateButton.OnClicked(func(button *ui.Button) {
		price := CalculatePriceWithGo(_days, _countriesComboBox, _seasonComboBox, _individualGuideCheckBox, _deluxeRoomCheckBox)
		totalBillLabel.SetText("Цiна: " + fmt.Sprintf("%.2f$", price))
	})

	window.OnClosing(func(*ui.Window) bool {
		ui.Quit()
		return true
	})
	window.Show()
}
