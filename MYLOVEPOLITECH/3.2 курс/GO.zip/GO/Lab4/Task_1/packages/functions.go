package functions

/*
#include<stdio.h>
#include<stdbool.h>
float CalculatePrice(float width, float height, int materialID, float cameras_count, bool is_windowsill)
{
	float cost = 0;
	switch (materialID)
	{
		case 0:
		{
			cost = (cameras_count == 0) ? 2.5: 3.0;
			break;
		}
		case 1:
		{
			cost = (cameras_count == 0) ? 0.5: 1.0;
			break;
		}
		case 2:
		{
			cost = (cameras_count == 0) ? 1.5: 2.0;
			break;
		}
	}

	float area = width * height;
	float price = area * cost;

	if (is_windowsill)
		price += 350;

	return price;
}
*/
import "C"

import (
	"fmt"
	"github.com/andlabs/ui"
	"strconv"
)

func CalculatePriceWithGo(fieldWidth *ui.Entry, fieldHeight *ui.Entry, f_mat *ui.Combobox, ch_isWindowsill *ui.Checkbox, s_camerasCount *ui.Combobox) float64 {
	var width = 0.0
	var height = 0.0
	if num, err := strconv.ParseFloat(fieldWidth.Text(), 64); err == nil {
		width = num
	}
	if num, err := strconv.ParseFloat(fieldHeight.Text(), 64); err == nil {
		height = num
	}
	var materials = f_mat.Selected()
	var isWindowsill = ch_isWindowsill.Checked()
	var numberOfCameras = s_camerasCount.Selected()

	var cost float64 = 0.0

	switch int(materials) {
	case 0:
		if float64(numberOfCameras) == 0 {
			cost = 2.5
		}
		if float64(numberOfCameras) == 1 {
			cost = 3.0
		}
	case 1:
		if float64(numberOfCameras) == 0 {
			cost = 0.5
		}
		if float64(numberOfCameras) == 1 {
			cost = 1.0
		}
	case 2:
		if float64(numberOfCameras) == 0 {
			cost = 1.5
		}
		if float64(numberOfCameras) == 1 {
			cost = 2.0
		}
	}
	var area float64 = width * height
	var price float64 = area * cost

	if bool(isWindowsill) {
		price += 350
	}
	return price
}

func CalculatePriceWithC(fieldWidth *ui.Entry, fieldHeight *ui.Entry, f_mat *ui.Combobox, ch_isWindowsill *ui.Checkbox, s_camerasCount *ui.Combobox) float64 {
	var width = 0.0
	var height = 0.0
	if num, err := strconv.ParseFloat(fieldWidth.Text(), 64); err == nil {
		width = num
	}
	if num, err := strconv.ParseFloat(fieldHeight.Text(), 64); err == nil {
		height = num
	}
	var materials = f_mat.Selected()
	var isWindowsill = ch_isWindowsill.Checked()
	var numberOfCameras = s_camerasCount.Selected()

	return (float64)(C.CalculatePrice(C.float(width), C.float(height), C.int(materials), C.float(numberOfCameras), C.bool(isWindowsill)))
}

func InitGUI() {
	window := ui.NewWindow("Калькулятор", 300, 200, false)
	window.SetMargined(true)

	windowContainer := ui.NewVerticalBox()
	windowContainer.SetPadded(true)

	inputsContainer := ui.NewHorizontalBox()
	inputsContainer.SetPadded(true)

	//----------
	sizeAndMaterialGroup := ui.NewGroup("Розмір вікна")
	sizeAndMaterialGroup.SetMargined(true)

	sizeAndMaterialForm := ui.NewForm()
	sizeAndMaterialForm.SetPadded(true)

	_height := ui.NewEntry()
	_width := ui.NewEntry()

	_materialComboBox := ui.NewCombobox()
	_materialComboBox.Append("Дерево")        //0
	_materialComboBox.Append("Метал")         //1
	_materialComboBox.Append("Металопластик") //2

	sizeAndMaterialForm.Append("Ширина, см", _height, false)
	sizeAndMaterialForm.Append("Висота, см", _width, false)
	sizeAndMaterialForm.Append("Матеріал", _materialComboBox, false)

	sizeAndMaterialGroup.SetChild(sizeAndMaterialForm)
	//^^^^

	//----------
	typeAndOptionsGroup := ui.NewGroup("Cклопакет")
	typeAndOptionsGroup.SetMargined(true)

	typeAndOptionsBox := ui.NewVerticalBox()
	typeAndOptionsBox.SetPadded(true)

	_camerasComboBox := ui.NewCombobox()
	_camerasComboBox.Append("Однокамерний")
	_camerasComboBox.Append("Двокамерний")

	typeAndOptionsBox.Append(_camerasComboBox, false)

	_windowsillCheckBox := ui.NewCheckbox("Підвіконня")
	typeAndOptionsBox.Append(_windowsillCheckBox, false)
	typeAndOptionsGroup.SetChild(typeAndOptionsBox)
	//^^^^

	//----------
	inputsContainer.Append(sizeAndMaterialGroup, false)
	inputsContainer.Append(typeAndOptionsGroup, false)

	windowContainer.Append(inputsContainer, false)
	//^^^^

	//----------
	totalBillBox := ui.NewVerticalBox()
	totalBillBox.SetPadded(true)

	calculateButton := ui.NewButton("Розрахувати")
	totalBillBox.Append(calculateButton, false)

	totalBillLabel := ui.NewLabel("00.00 грн")
	totalBillBox.Append(totalBillLabel, false)
	//^^^^

	windowContainer.Append(totalBillBox, true)
	window.SetChild(windowContainer)

	calculateButton.OnClicked(func(button *ui.Button) {
		price := CalculatePriceWithC(_width, _height, _materialComboBox, _windowsillCheckBox, _camerasComboBox)
		totalBillLabel.SetText("Цiна: " + fmt.Sprintf("%.2f", price))
	})

	window.OnClosing(func(*ui.Window) bool {
		ui.Quit()
		return true
	})
	window.Show()
}
