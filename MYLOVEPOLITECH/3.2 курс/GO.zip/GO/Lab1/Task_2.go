package main

func main() {
	var variable int64 = 15
	variable++
}
