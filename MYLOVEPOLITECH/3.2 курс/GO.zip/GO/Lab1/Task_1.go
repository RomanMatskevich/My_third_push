package main

import "fmt"

func main() {
	var str string = "Golang!"
	fmt.Println("Привіт", str)
}
