package main

import (
	"fmt"
)

func main() {
	var chartype int8 = 'R'

	fmt.Printf("Code '%c' - %d\n", chartype, chartype)

	//Завдання. 1. Вивести українську букву 'Ї'
	fmt.Println("\nЗавдання. 1. Вивести українську букву 'Ї'")

	var letter rune = 'Ї'
	fmt.Printf("%#U %T", letter, letter)

	//Завдання 2. Пояснити призначення типу "rune"
	fmt.Println("\n\nЗавдання 2. Пояснити призначення типу rune")
	fmt.Println("Тип rune є типом псевдонімом типу int32 і також займає 4 байти.\n" +
		"Має таке ж призначення, як і тип char у C# та багатьох інших мовах  - зберігати коди Unicode-символів.\n" +
		"кожен Unicode-символ має унікальний ID, який зберігається у типі rune\n")
}
