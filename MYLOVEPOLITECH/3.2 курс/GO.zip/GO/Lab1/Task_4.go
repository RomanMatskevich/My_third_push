package main

import "fmt"

func main() {
	var c int64 = 10
	c--
	fmt.Println("c--     = ", c)
}
