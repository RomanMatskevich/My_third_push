package main

import "fmt"

func main() {
	//Инициализация переменных

	var userinit8 uint8 = 1
	var userinit16 uint16 = 2
	var userinit64 int64 = -3
	var userautoinit = -4

	intVar := 10

	fmt.Printf("userinit8 = %d Type = %T\nuserinit16 = %d Type = %T\nuserinit64 = %d Type = %T\nuserautoinit = %d Type = %T\nintVar = %d Type = %T\n",
		userinit8, userinit8, userinit16, userinit16, userinit64, userinit64, userautoinit, userautoinit, intVar, intVar)

	intVar = int(userinit16)
	fmt.Println("intVar = ", intVar)

	intVar = userautoinit
	fmt.Println("intVar = ", intVar)
}
