package main

import (
	"fmt"
	"math"
	"reflect"
	"unsafe"
)

func main() {
	var defaultFloat float32
	var defaultDouble float64 = 5.5

	fmt.Println("defaultfloat       = ", defaultFloat)
	fmt.Printf("defaultDouble (%T) = %f\n\n", defaultDouble, defaultDouble)

	fmt.Println("MAX float32        = ", math.MaxFloat32)
	fmt.Println("MIN float32        = ", math.SmallestNonzeroFloat32, "\n")

	fmt.Println("MAX float64        = ", math.MaxFloat64)
	fmt.Println("MIN float64        = ", math.SmallestNonzeroFloat64, "\n")

	// Завдання. 1. Создайте переменные разных типов, используя краткую запись и инициализацию по-умолчанию. Результат вывести
	var complex64 complex64
	complexNumber := 1000 + 200
	fmt.Println("Default complex - ", complex64, "type - ", reflect.TypeOf(complex64))
	fmt.Println("Complex - ", complexNumber, "Type - ", reflect.TypeOf(complexNumber))

	runesArray := []rune("✌🌚")
	fmt.Println("Runes - ", runesArray, "Type - ", reflect.TypeOf(runesArray))

	var defaultString string
	str := "Some string"
	fmt.Println("Default string - ", defaultString, "type - ", reflect.TypeOf(defaultString))
	fmt.Println("String - ", str, "Type - ", reflect.TypeOf(str))

	var defaultBoolean bool
	isTrue := true
	fmt.Println("Default boolean - ", defaultBoolean, "Type - ", reflect.TypeOf(defaultBoolean))
	fmt.Println("Boolean - ", isTrue, "Type - ", reflect.TypeOf(isTrue), "size: ", unsafe.Sizeof(isTrue))

	var defaultUint8 uint8
	numberInt := 500
	fmt.Println("DefaultUint8 - ", defaultUint8, "Type - ", reflect.TypeOf(defaultUint8))
	fmt.Println("Int - ", numberInt, "Type - ", reflect.TypeOf(numberInt), "Size - ", unsafe.Sizeof(numberInt))

	var defaultFloat32 float32
	fmt.Println("Float32 - ", defaultFloat32, "Type - ", reflect.TypeOf(defaultFloat32), "Size - ", unsafe.Sizeof(defaultFloat32))

	first, second := 5.2, -60234545.23
	fmt.Println("Float64 - ", first, "Type - ", reflect.TypeOf(first), "Size - ", unsafe.Sizeof(first))
	fmt.Println("Float64 - ", second, "Type - ", reflect.TypeOf(second), "Size - ", unsafe.Sizeof(second))
}
