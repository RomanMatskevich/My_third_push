package main

import "fmt"

func main() {
	var first, second bool
	var third bool = true
	fourth := !third
	var fifth = true

	fmt.Println("first  = ", first)       // false
	fmt.Println("second = ", second)      // false
	fmt.Println("third  = ", third)       // true
	fmt.Println("fourth = ", fourth)      // false
	fmt.Println("fifth  = ", fifth, "\n") // true

	fmt.Println("!true  = ", !true)        // false
	fmt.Println("!false = ", !false, "\n") // true

	fmt.Println("true && true   = ", true && true)         // true
	fmt.Println("true && false  = ", true && false)        // false
	fmt.Println("false && false = ", false && false, "\n") // false

	fmt.Println("true || true   = ", true || true)         // true
	fmt.Println("true || false  = ", true || false)        // true
	fmt.Println("false || false = ", false || false, "\n") // false

	fmt.Println("2 < 3  = ", 2 < 3)        // true
	fmt.Println("2 > 3  = ", 2 > 3)        // false
	fmt.Println("3 < 3  = ", 3 < 3)        // false
	fmt.Println("3 <= 3 = ", 3 <= 3)       // true
	fmt.Println("3 > 3  = ", 3 > 3)        // false
	fmt.Println("3 >= 3 = ", 3 >= 3)       // true
	fmt.Println("2 == 3 = ", 2 == 3)       // false
	fmt.Println("3 == 3 = ", 3 == 3)       // true
	fmt.Println("2 != 3 = ", 2 != 3)       // true
	fmt.Println("3 != 3 = ", 3 != 3, "\n") // false

	//Задание.
	//1. Пояснить результаты операций
	fmt.Println("Пояснення:\n" +
		"\t 1: Значення змінної first рівне false, оскількт нульове значення для типу bool = false\n" +
		"\t 2: Значення змінної second рівне false, оскількт нульове значення для типу bool = false\n" +
		"\t 3: Змінну third ініціалізовано значенням true\n" +
		"\t 4: Змінна fourth ініціалізована !third, тобто false\n" +
		"\t 5: Змінну fifth ініціалізовано як true\n" +
		"\t 6 та 7: при використанні '!' значення bool змінюється на протилежне(true = !false)\n" +
		"\t 8, 9 та 10: при використанні '&&' всі вирази повинні давати значення true, тож  true && true = true; true && false = false; false && false = false\n" +
		"\t 11, 12 та 13: при використанні '||' один з виразів повинен давати значення true, тож  true || true = true; true || false = true; false || false = false\n" +
		"\t 14: 2 < 3: правильно, тому true\n" +
		"\t 15: 2 > 3: 2 < 3, тому false\n" +
		"\t 16: 3 < 3: 3 = 3, тому false\n" +
		"\t 17: 3 <= 3: 3 ≤ 3, тому true\n" +
		"\t 18: 3 > 3: 3 = 3, тому false\n" +
		"\t 19: 3 >= 3: 3 ≥ 3, тому true\n" +
		"\t 20: 2 != 3: 2 != 3,тому true\n" +
		"\t 21: 3 != 3: 3 = 3 тому false")

}
