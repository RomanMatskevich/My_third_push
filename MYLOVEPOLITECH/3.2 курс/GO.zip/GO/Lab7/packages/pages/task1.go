package pages

import (
	"fmt"
	"math"
	"net/http"
	"strconv"
)

type PageTask1 string

func (s PageTask1) Count(a float64, b float64, c float64) (float64, float64, int) {
	if a == 0 && b == 0 && c == 0 {
		return 0, 0, 0
	}
	D := b*b - 4*a*c
	if D > 0 {
		x1 := (-b + math.Sqrt(D)) / (2 * a)
		x2 := (-b - math.Sqrt(D)) / (2 * a)
		return x1, x2, 2
	}
	if D == 0 {
		x1 := (-b + math.Sqrt(D)) / (2 * a)
		return x1, x1, 1
	}
	return 0, 0, 0
}

func ReturnResultStringTask1(x1 float64, x2 float64, solved int) string {
	if solved == 2 {
		return fmt.Sprintf("<h4>x1 = %.2f x2 = %.2f </h4>", x1, x2)
	}
	if solved == 1 {
		return fmt.Sprintf("<h4>x1 = %.2f </h4>", x1)
	}
	return fmt.Sprint("<h4>No solution </h4>")
}

func (s PageTask1) ServeHTTP(writer http.ResponseWriter, request *http.Request) {
	fmt.Fprint(writer, bodyStart, pageHeader, s.Render())

	switch request.Method {
	case "POST":
		err := request.ParseForm()
		post := request.PostForm
		if err != nil {
			fmt.Fprintf(writer, anError, err)
			return
		}
		a, _ := strconv.ParseFloat(post.Get("a"), 32)
		b, _ := strconv.ParseFloat(post.Get("b"), 32)
		c, _ := strconv.ParseFloat(post.Get("c"), 32)
		fmt.Fprint(writer, ReturnResultStringTask1(s.Count(a, b, c)))
		break
	case "GET":
		a, _ := strconv.ParseFloat(request.FormValue("a"), 32)
		b, _ := strconv.ParseFloat(request.FormValue("b"), 32)
		c, _ := strconv.ParseFloat(request.FormValue("c"), 32)
		fmt.Fprint(writer, ReturnResultStringTask1(s.Count(a, b, c)))

	}
	fmt.Fprint(writer, "\n", bodyEnd)
	fmt.Fprint(writer, "\n", pageFooter)
}

func (s PageTask1) Render() string {
	return `
		<h1>Task 1</h1>
		<h3>Post</h3>
		<form action="/task1" method="POST">
			<input type="number" placeholder="a" name="a"/>
			<input type="number" placeholder="b" name="b"/>
			<input type="number" placeholder="c" name="c"/>
			<button type="submit" value="Count">Count</button>
		</form>

		<h3>Get</h3>
		<form action="/task1" method="GET">
			<input type="number" placeholder="a" name="a"/>
			<input type="number" placeholder="b" name="b"/>
			<input type="number" placeholder="c" name="c"/>
			<button type="submit" value="Count">Count</button>
		</form>
	`
}
