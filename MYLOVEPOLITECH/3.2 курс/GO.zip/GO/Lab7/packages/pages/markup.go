package pages

const (
	pageHeader = `<!DOCTYPE HTML>
<html>
<head>
<title>Lab7</title>
<style>
.error{
color:#FF0000;
}
</style>
</head>`
	bodyStart = `<body>`
	bodyEnd   = `</body>`
	//	form      = `<form action="/" method="POST">
	//<label for="numbers">Введите число:</label><br />
	//<input type="text" name="numbers" size="20" value="5"><br />
	//<input type="submit" value="Выполнить">
	//</form>`
	pageFooter = `</html>`
	//	table      = `<table border="1">
	//<tr><th colspan="2">Результат</th></tr>
	//<tr><td>Строка 1</td><td>%s</td></tr>
	//<tr><td>Строка 2</td><td>%f</td></tr>
	//</table>`
	anError = `<p class="error">%s</p>`
)
