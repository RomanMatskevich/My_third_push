package pages

import (
	"fmt"
	"net/http"
	"strconv"
	"strings"
)

type PageTask2 string

func (s PageTask2) ParseArray(text string) []float64 {

	arrString := strings.Split(text, ",")
	var result []float64
	for _, element := range arrString {
		i, _ := strconv.ParseFloat(element, 32)
		result = append(result, i)
	}
	return result
}

func (s PageTask2) ProdOfPosNumbers(array []float64) float64 {
	var prod float64 = 0
	for i := 0; i < len(array); i++ {
		if array[i] < 0 {
			prod = prod + array[i]
		}
	}
	return prod
}

func (s PageTask2) ProductOfElements(array []float64) float64 {
	var product float64 = 1

	for i := 0; i < len(array); i++ {
		product = product * array[i]
	}
	return product
}
func ReturnResultStringTask2(ProdOfPosNumbers float64, ProductOfElements float64) string {
	return fmt.Sprintf("<h4>Sum of negative numbers: %.2f</h4>\n", ProdOfPosNumbers) +
		fmt.Sprintf("<h4>Product of elements: %.2f</h4>", ProductOfElements)
}

func (s PageTask2) ServeHTTP(writer http.ResponseWriter, request *http.Request) {
	fmt.Fprint(writer, bodyStart, pageHeader, s.Render())
	fmt.Fprint(writer, "<h4>Task2</h4>")

	switch request.Method {
	case "POST":
		err := request.ParseForm()
		post := request.PostForm
		if err != nil {
			fmt.Fprintf(writer, anError, err)
			return
		}
		arr := s.ParseArray(post.Get("numsArr"))
		fmt.Fprint(writer, ReturnResultStringTask2(s.ProdOfPosNumbers(arr), s.ProductOfElements(arr)))
		break
	case "GET":
		arr := s.ParseArray(request.FormValue("numsArr"))
		fmt.Fprint(writer, ReturnResultStringTask2(s.ProdOfPosNumbers(arr), s.ProductOfElements(arr)))
		break
	}
	fmt.Fprint(writer, "\n", bodyEnd)
	fmt.Fprint(writer, "\n", pageFooter)
}

func (s PageTask2) Render() string {
	return `
		<h1>Task 2</h1>
		<h3>Post</h3>
		<form method="POST">
			<input type="text" placeholder="Введіть числа через кому" name="numsArr" id="inputField"/>

			<button type="submit" value="Count">Count</button>
		</form>
		<h3>Get</h3>
		<form method="GET">
			<input type="text" placeholder="Введіть числа через кому" name="numsArr" id="inputField"/>
			<button type="submit" value="Count">Count</button>
		</form>
	`
}
