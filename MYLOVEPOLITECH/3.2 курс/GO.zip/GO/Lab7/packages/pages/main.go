package pages

import (
	"fmt"
	"net/http"
)

type PageMain string

func (s PageMain) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	fmt.Fprint(w, pageHeader, s.Render())
	fmt.Fprint(w, "\n", pageFooter)
}

func (s PageMain) Render() string {
	return `
	<h3>Lab 7</h3>
	<h4><a href="/task1">Task 1</a></h4>
	<h4><a href="/task2">Task 2</a></h4>
`
}
