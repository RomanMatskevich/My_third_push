package main
//варіант 19-3
import (
	pages "Lab7/packages/pages"
	"fmt"
	"net/http"
)

var pageMain pages.PageMain = "Main"
var pageTask1 pages.PageTask1 = "Task1"
var pageTask2 pages.PageTask2 = "Task2"

func main() {

	mux := http.NewServeMux()
	mux.HandleFunc("/", pageMain.ServeHTTP)
	mux.HandleFunc("/task1", pageTask1.ServeHTTP)
	mux.HandleFunc("/task2", pageTask2.ServeHTTP)

	fmt.Println("Server works at http://localhost:5000")
	http.ListenAndServe("localhost:5000", mux)
}
