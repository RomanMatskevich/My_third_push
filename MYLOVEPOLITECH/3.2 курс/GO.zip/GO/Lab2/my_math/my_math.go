package my_math

func Min(x1 float64, x2 float64, x3 float64) float64 {
	if x1 < x2 && x1 < x3 {
		return x1
	}
	if x2 < x1 && x2 < x3 {
		return x2
	}
	return x3
}

func Avg(x1 float64, x2 float64, x3 float64) float64 {
	return (x1 + x2 + x3) / 3
}
func Equation(y float64) float64 {
	//y = kx + b => x = (b - y) / k
	return (10 - y) / 2
}
