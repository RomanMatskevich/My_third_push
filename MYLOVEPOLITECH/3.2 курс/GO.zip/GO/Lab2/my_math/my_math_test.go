package my_math

import "testing"

func TestMin(t *testing.T) {
	x := Min(1, 2, -3)
	var res float64 = -3
	if x != res {
		t.Errorf("Тест не пройдений! Результат %f, а повинен бути %f", x, res)
	}
}

func TestAwg(t *testing.T) {
	x := Avg(10, 2, 3)
	var res float64 = 5
	if x != res {
		t.Errorf("Тест не пройдений! Результат %f, а повинен бути %f", x, res)
	}
}

func TestEquation(t *testing.T) {
	x := Equation(2)
	var res float64 = 4
	if x != res {
		t.Errorf("Тест не пройдений! Результат %f, а повинен бути %f", x, res)
	}
}
