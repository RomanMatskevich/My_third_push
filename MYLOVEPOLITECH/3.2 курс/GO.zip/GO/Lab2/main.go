package main

import (
	"Lab2/my_math"
	"fmt"
)

func main() {

	fmt.Println(my_math.Min(1, -3, 3))
	fmt.Println(my_math.Avg(10, 2, 3))
	fmt.Println(my_math.Equation(2))
}

//Task_3--------------

//func min(x1 float64, x2 float64, x3 float64) float64 {
//	if x1 < x2 && x1 < x3 {
//		return x1
//	}
//	if x2 < x1 && x2 < x3 {
//		return x2
//	}
//	return x3
//}
//
//func avg(x1 float64, x2 float64, x3 float64) float64 {
//	return (x1 + x2 + x3) / 3
//}
//func equation(y float64) float64 {
//	//y = kx + b => x = (b - y) / k
//	return (10 - y) / 2
//}
//^^^^^^^^^^^^^^^^^
