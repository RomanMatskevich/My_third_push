import './App.css';
import TeamApp from "./Task02/TeamApp";

function App() {
  return (
    <div className="App">
      <TeamApp />
    </div>
  );
}

export default App;
