import {useState, useContext} from 'react';
import {Button, Input, Row, Space} from "antd";

import {TeamsContext} from "./teamsContext";

const TeamForm = () => {
  const {dispatch, teams, setIsChange} = useContext(TeamsContext);
  
  const [name, setName] = useState('');
  
  const addHandler = () => {
    if (name !== '') {
      const id = (teams && teams.length > 0) ? teams[teams.length - 1].id + 1 : 0;
      
      dispatch({type: 'ADD_TEAM', id, name});
    }
    
    setName('');
    setIsChange(true);
  }
  
  return (
    <Row>
      <Space>
        <Input value={name} placeholder="Chelsea FC" onChange={(e) => setName(e.target.value)} style={{width: '300px'}}/>
      
        <Button onClick={addHandler} type="primary">Add</Button>
      </Space>
    </Row>
  );
};

export default TeamForm;
