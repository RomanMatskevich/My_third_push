import {useReducer, useState, useEffect} from 'react';

import reducer from "./reducer";
import TeamForm from "./TeamForm";
import TeamsList from "./TeamsList";
import {TeamsContext} from "./teamsContext";

const TeamApp = () => {
  const [teams, dispatch] = useReducer(reducer, null);
  const [message, setMessage] = useState('');
  const [isChange, setIsChange] = useState(false);
  
  useEffect(() => {
    const storageTeams = JSON.parse( localStorage.getItem('teams') );
    
    if (storageTeams)
      dispatch({type: 'POPULATE_TEAMS', payload: storageTeams || []});
  }, []);
  
  useEffect(() => {
    if (teams !== null)
      localStorage.setItem('teams', JSON.stringify(teams));
  }, [teams]);
  
  const removeHandler = (id) => {
    dispatch({type: 'REMOVE_TEAM', id});
    setIsChange(true);
  }
  
  return (
    <TeamsContext.Provider value={{
      dispatch,
      teams,
      setIsChange,
      message,
      setMessage,
      isChange,
      removeHandler
    }}
    >
      <div style={{marginTop: '20px'}}>
        <h1 style={{marginRight: '300px'}}>Team App</h1>
        
        <TeamForm />
    
        <TeamsList />
      </div>
    </TeamsContext.Provider>
  );
};

export default TeamApp;
