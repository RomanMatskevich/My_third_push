import {useEffect, useContext} from "react";

import {Button, Space} from "antd";
import {AiFillDelete} from "react-icons/ai";
import {TeamsContext} from "./teamsContext";

const Team = ({id, name}) => {
  const {removeHandler, setMessage, change} = useContext(TeamsContext);
  
  useEffect(() => {
    change ? setMessage(`Team with name "${name}" have been added.`) : setMessage(``);
    
    return () => setMessage(`Team with name "${name}" have been deleted.`);
  }, []);
  
  return (
    <Space key={id} style={{marginTop: '5px'}}>
      <li style={{width: '120px', marginLeft: '-100px'}}>{name}</li>
      <Button onClick={() => removeHandler(id)}>
        <AiFillDelete color="red"/>
      </Button>
    </Space>
  );
};

export default Team;
