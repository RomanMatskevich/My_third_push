import {Layout, Row, Space} from "antd";
import {useContext} from "react";

import Team from './Team';
import {TeamsContext} from "./teamsContext";

const TeamsList = () => {
  const {teams, message} = useContext(TeamsContext);
  
  return (
    <Layout style={{background: 'white' , marginTop: '15px'}}>
      <Row style={{marginTop: '10px'}}>
        <Space>
          <ul style={{width: '300px',  listStyle: 'none'}}>
            {teams && teams.map(t =>
              <Team key={t.id} id={t.id} name={t.name}/>
            )}
          </ul>
        </Space>
  
        <div>
          {message}
        </div>
      </Row>
    </Layout>
  );
};

export default TeamsList;
