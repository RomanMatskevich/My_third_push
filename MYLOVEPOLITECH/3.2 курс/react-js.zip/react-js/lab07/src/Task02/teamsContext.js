import {createContext} from "react";

export const TeamsContext = createContext();