import TeamsList from './Task02/TeamsList';
import './App.css';

function App() {
  return (
    <div className="App">
      <TeamsList />
    </div>
  );
}

export default App;
