import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";

import './App.css';
import Main from './components/Main';
import Task01 from './components/Task01/Task01';
import Task02 from './components/Task02/Task02';
import Notification from "./Notification";

function App() {
  return (
    <div className="App">
      <Router>
        <Routes>
          <Route path="*" exact element={<Main/>}/>
          <Route path="/" exact element={<Main/>}/>
          <Route path="/home" exact element={<Main/>}/>
      
          <Route path="/task01" element={<Task01/>}/>
          <Route path="/task02" element={<Task02/>}/>
        </Routes>
      </Router>
  
      <Notification/>
    </div>
  );
}

export default App;
