import {useNavigate} from "react-router-dom";

const Main = () => {
  const navigate = useNavigate();
  
  return (
    <div>
      <h1 style={{textAlign: 'center'}}>
        ReactJS. Lab06. Oleksii Bubenko. IPZ-20-2.
      </h1>
    
      <ul style={{fontSize: '24px'}}>
        <li style={{cursor: 'pointer', marginTop: '10px'}} onClick={() => navigate("/task01")}>Task01</li>
        <li style={{cursor: 'pointer', marginTop: '10px'}} onClick={() => navigate("/task02")}>Task02</li>
      </ul>
    </div>

  );
};

export default Main;
