import {useState} from "react";
import {useNavigate} from "react-router-dom";
import {toast} from "react-toastify";
import {useForm} from "react-hook-form";
import {yupResolver} from "@hookform/resolvers/yup";
import * as yup from "yup";

import styles from './task02.module.scss';

const mainSchema = yup.object().shape({
  cityFrom: yup.string().required("Оберіть місто-відправник"),
  cityTo: yup.string().required("Оберіть місто-одержувач"),
  shipment: yup.string().required("Оберіть вид відправлення"),
  floor: yup.number().positive()
    .min(1, "Мінімальний поверх 1й")
    .max(30, "Максимальний поверх 30й")
    .typeError("Оберіть поверх від 1 до 30"),
  isLift: yup.boolean(),
  isPackaging: yup.boolean(),
  isReverseDelivery: yup.boolean(),
  reverseDelivery: yup.string(),
  isPalletizing: yup.boolean(),
});

const packagingSchema = yup.object().shape({
  typeOfPackaging: yup.string().required("Оберіть вид пакування"),
  countPackaging: yup.number().default(1)
});

const palletePlaceSchema = yup.object().shape({
  typeOfPallete: yup.string().required("Оберіть вид палети"),
  cost: yup.number().required("Оберіть оголошену вартість")
    .min(1, "Мінімальна вартість 1")
    .typeError("Оберіть вартість від 1"),
  count: yup.number().required("Оберіть кількість").positive()
    .min(1, "Мінімальна кількість 1")
    .max(30, "Максимальна кількість 1000")
    .typeError("Оберіть кількість від 1 до 1000")
});

const cargoPlaceSchema = yup.object().shape({
  cost: yup.number().required("Оберіть оголошену вартість").positive()
    .min(1, "Мінімальна вартість 1")
    .typeError("Оберіть оголошену вартість"),
  count: yup.number().required("Оберіть кількість").positive()
    .min(1, "Мінімальна кількість 1")
    .max(1000, "Максимальна кількість 1000")
    .typeError("Оберіть кількість від 1 до 1000"),
  weight: yup.number("Оберіть вагу від 1 кг").required("Оберіть вагу").positive()
    .min(1, "Мінімальна вага 1 кг")
    .typeError("Оберіть вагу від 1 кг"),
  length: yup.number().required("Оберіть довжину").positive()
    .min(1, "Мінімальна довжина 1 см")
    .typeError("Оберіть довжину від 1 см"),
  width: yup.number().required("Оберіть ширину").positive()
    .min(1, "Мінімальна ширина 1 см")
    .typeError("Оберіть ширину від 1 см"),
  height: yup.number().required("Оберіть висоту").positive()
    .min(1, "Мінімальна висота 1 см")
    .typeError("Оберіть висоту від 1 см")
});

const Task02 = () => {
  const navigate = useNavigate();
  
  const [isTwoPlaces, setIsTwoPlaces] = useState(false);
  
  const cities = ['Овруч', 'Звягель', 'Коростень', 'Олевськ', 'Малин',
    'Народичі', 'Лугини', 'Ємільчине', 'Городниця', 'Білокоровичі'];
  
  const shipments = ['Палети', 'Вантажі'];
  
  const reverseDeliveries = ['Документи', 'Грошовий переказ'];
  
  const packagingTypes = [
    'Конверт з ПБ плівкою С/13 (150х215) мм',
    'Конверт з ПБ плівкою D/14 (180х265) мм',
    'Конверт з ПБ плівкою E/15 (220х265) мм',
    'Коробка (0,5 кг) пласка',
    'Коробка (0,5 кг) пласка з наповнювачем',
    'Коробка (0,5 кг) стандартна',
    'Коробка (1 кг) пласка',
    'Коробка (1 кг) стандартна з наповнювачем',
    'Коробка (20 кг)',
    'Коробка (30 кг) з наповнювачем',
    'Коробка (30 кг)',
    'Коробка (4кг) для ноутбука',
    'Пакування в стрейч плівку (2-30 кг)',
    'Коробка (40 кг) з наповнювачем',
    'Плівка повітряно-пузиркова 1*1м',
    'Тубус 120 Прямокутний',
    'Тубус 60 Прямокутний',
    'Flat-бокс (великий)',
    'Flat-бокс (малий)',
  ];
  
  const palleteTypes = [
    'Палета від 1 м2 до 1,49 м2 (612)',
    'Палета від 1,5 м2 до 2 м2 (816)',
    'Палета від 0,5 м2 до 0,99 м2 (408)',
    'Палета до 0,49 м2 (204)'
  ];
  
  const mainForm = useForm({
    resolver: yupResolver(mainSchema),
    mode: 'onChange'
  });
  
  const firstPackagingForm = useForm({
    resolver: yupResolver(packagingSchema),
    mode: 'onChange'
  });
  
  const firstPalleteForm = useForm({
    resolver: yupResolver(palletePlaceSchema),
    mode: 'onChange'
  });
  
  const secondPalleteForm = useForm({
    resolver: yupResolver(palletePlaceSchema),
    mode: 'onChange'
  });
  
  const fistCargoForm = useForm({
    resolver: yupResolver(cargoPlaceSchema),
    mode: 'onChange'
  });
  
  const secondCargoForm = useForm({
    resolver: yupResolver(cargoPlaceSchema),
    mode: 'onChange'
  });
  
  const submit = (data) => {
    const request = {};
    
    request.cityFrom = data.cityFrom;
    request.cityTo = data.cityTo;
    request.shipment = data.shipment;
    request.floor = data.floor;
    request.isLift = data.isLift;
    request.isPackaging = data.isPackaging;
    request.isReverseDelivery = data.isReverseDelivery;
    
    if (data.isReverseDelivery) {
      request.reverseDelivery = data.reverseDelivery;
    }
    
    if (data.shipment === shipments[0]) {
      request.isPalletizing = data.isPalletizing;
    }
    
    if (data.isPackaging) {
      request.packagingValues = {
        typeOfPackaging: firstPackagingForm.watch('typeOfPackaging'),
        count: firstPackagingForm.watch('count') || 1
      }
    }
    
    if (data.shipment === shipments[0]) {
      const {typeOfPallete, count, cost} = firstPalleteForm.watch();
      
      if (!typeOfPallete || !count || !cost || Object.keys(firstPalleteForm.formState.errors).length !== 0) {
        toast.error('Перевірте введені значення 1-го місця');
        return;
      }

      const placesList = [{typeOfPallete, count, cost}];
      
      if (isTwoPlaces) {
        const {typeOfPallete, count, cost} = secondPalleteForm.watch();
  
        if (!typeOfPallete || !count || !cost || Object.keys(secondPalleteForm.formState.errors).length !== 0) {
          toast.error('Перевірте введені значення 2-го місця');
          return;
        }
  
        placesList.push({typeOfPallete, count, cost});
      }
      
      request.placesList = placesList;
    }
  
    if (data.shipment === shipments[1]) {
      const {count, cost, width, weight, length, height} = fistCargoForm.watch();
    
      console.log(fistCargoForm.formState.errors);
      
      if (!count || !cost || !width || !height || !length || !width || Object.keys(fistCargoForm.formState.errors).length !== 0) {
        toast.error('Перевірте введені значення 1-го місця');
        return;
      }
    
      const placesList = [{count, cost, width, weight, height, length}];
    
      if (isTwoPlaces) {
        const {count, cost, width, weight, length, height} = secondCargoForm.watch();
  
        if (!count || !cost || !width || !height || !length || !width || Object.keys(secondCargoForm.formState.errors).length !== 0) {
          toast.error('Перевірте введені значення 2-го місця');
          return;
        }
  
        placesList.push([{count, cost, width, weight, height, length}]);
      }
    
      request.placesList = placesList;
    }
    
    console.log('REQUEST', request);
    clear();
  }
  
  const clear = () => {
    mainForm.setValue('shipment', '');
    mainForm.setValue('cityTo', '');
    mainForm.setValue('cityFrom', '');
    mainForm.setValue('floor', '');
    mainForm.setValue('isLift', false);
    mainForm.setValue('isPackaging', false);
    mainForm.setValue('isPalletizing', false);
  
    mainForm.clearErrors('cityTo');
    mainForm.clearErrors('cityFrom');
    mainForm.clearErrors('shipment');
    mainForm.clearErrors('floor');
    
    clearPackaging();
    clearPlaces();
  }
  
  const clearPackaging = () => {
    firstPackagingForm.setValue('typeOfPackaging', '');
    firstPackagingForm.clearErrors('typeOfPackaging');
  }
  
  const clearPlaces = () => {
    setIsTwoPlaces(false);
    
    firstPalleteForm.setValue('typeOfPallete', '');
    firstPalleteForm.setValue('cost', '');
    firstPalleteForm.setValue('count', '');
  
    secondPalleteForm.setValue('typeOfPallete', '');
    secondPalleteForm.setValue('cost', '');
    secondPalleteForm.setValue('count', '');
    
    firstPalleteForm.clearErrors('typeOfPallete');
    firstPalleteForm.clearErrors('cost');
    firstPalleteForm.clearErrors('count');
  
    secondPalleteForm.clearErrors('typeOfPallete');
    secondPalleteForm.clearErrors('cost');
    secondPalleteForm.clearErrors('count');
  
    fistCargoForm.setValue('cost', '');
    fistCargoForm.setValue('count', '');
    fistCargoForm.setValue('weight', '');
    fistCargoForm.setValue('length', '');
    fistCargoForm.setValue('height', '');
    fistCargoForm.setValue('width', '');
  
    fistCargoForm.clearErrors('cost');
    fistCargoForm.clearErrors('count');
    fistCargoForm.clearErrors('weight');
    fistCargoForm.clearErrors('length');
    fistCargoForm.clearErrors('height');
    fistCargoForm.clearErrors('width');
  
    secondCargoForm.setValue('cost', '');
    secondCargoForm.setValue('count', '');
    secondCargoForm.setValue('weight', '');
    secondCargoForm.setValue('length', '');
    secondCargoForm.setValue('height', '');
    secondCargoForm.setValue('width', '');
  
    secondCargoForm.clearErrors('cost');
    secondCargoForm.clearErrors('count');
    secondCargoForm.clearErrors('weight');
    secondCargoForm.clearErrors('length');
    secondCargoForm.clearErrors('height');
    secondCargoForm.clearErrors('width');
  }
  
  return (
    <div>
      <div className={styles.titleContainer}>
        <img className={styles.logo} alt={"logo"} src={"https://i.pinimg.com/236x/1e/99/c4/1e99c47e8998ef9fa985aaef94c562bd.jpg"}/>
        <h1 className={styles.title}>Вартість доставки</h1>
      </div>
  
      <p>Орієнтовна вартість перевезення, яку сплачує Відправник.</p>
      <div className={styles.form}>
        <form onSubmit={mainForm.handleSubmit(submit)}>
          <div className={styles.routeContainer}>
            <p className={styles.name}>Маршрут</p>
            
            <label style={{marginLeft: '30px', marginRight: '5px'}}>від</label>
            <select {...mainForm.register('cityFrom')} style={{outline: 'none', width: '150px'}}>
              <option value=""></option>
              {cities.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
  
            <label style={{marginLeft: '30px', marginRight: '5px'}}>до</label>
            <select {...mainForm.register('cityTo')} style={{outline: 'none', width: '150px'}}>
              <option value=""></option>
              {cities.reverse().map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            <p className={styles.error}>{mainForm.formState.errors.cityTo?.message || mainForm.formState.errors.cityFrom?.message}</p>
          </div>
  
          <div className={styles.routeContainer}>
            <p className={styles.name}>Вид відправлення</p>
    
            <select {...mainForm.register('shipment')} style={{outline: 'none', width: '150px', marginLeft: '30px'}}>
              <option value=""></option>
              {shipments.map(c => <option key={c} value={c}>{c}</option>)}
            </select>
            
            <p className={styles.error}>{mainForm.formState.errors.shipment?.message}</p>
          </div>
  
          {mainForm.watch("shipment") === shipments[0] &&
            <div>
              <div className={styles.routeContainer}>
                <label style={{marginRight: '5px'}}>Тип палети</label>
    
                <select {...firstPalleteForm.register('typeOfPallete')} style={{outline: 'none', width: '150px', marginLeft: '30px'}}>
                  <option value=""></option>
                  {palleteTypes.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                
                <label style={{marginRight: '5px', marginLeft: '10px'}}>Вартість</label>
                <input type={"number"} style={{width: '50px'}} {...firstPalleteForm.register('cost')}/>
  
                <label style={{marginRight: '5px', marginLeft: '10px'}}>Кількість</label>
                <input type={"number"} style={{width: '50px'}} {...firstPalleteForm.register('count')}/>
  
                <p className={styles.error}>{
                  firstPalleteForm.formState.errors.typeOfPallete?.message ||
                  firstPalleteForm.formState.errors.cost?.message ||
                  firstPalleteForm.formState.errors.count?.message
                }</p>
              </div>
              
              {isTwoPlaces &&
                <div style={{marginTop: '10px'}} className={styles.routeContainer}>
                  <label style={{marginRight: '5px'}}>Тип палети</label>
    
                  <select {...secondPalleteForm.register('typeOfPallete')} style={{outline: 'none', width: '150px', marginLeft: '30px'}}>
                    <option value=""></option>
                    {palleteTypes.map(c => <option key={c} value={c}>{c}</option>)}
                  </select>
  
                  <label style={{marginRight: '5px', marginLeft: '10px'}}>Вартість</label>
                  <input type={"number"} style={{width: '50px'}} {...secondPalleteForm.register('cost')}/>
  
                  <label style={{marginRight: '5px', marginLeft: '10px'}}>Кількість</label>
                  <input type={"number"} style={{width: '50px'}} {...secondPalleteForm.register('count')}/>
                  
                  <p className={styles.error}>{
                    secondPalleteForm.formState.errors.typeOfPallete?.message ||
                    secondPalleteForm.formState.errors.cost?.message ||
                    secondPalleteForm.formState.errors.count?.message
                  }</p>
  
                  <a onClick={() => setIsTwoPlaces(false)} style={{color: 'red', marginLeft: '10px'}}>❌</a>
                </div>
              }
              
              <a onClick={() => setIsTwoPlaces(true)} className={styles.clear}>
                Додати місце
              </a>
            </div>
          }
  
          {mainForm.watch("shipment") === shipments[1] &&
            <div>
              <div className={styles.routeContainer}>
                <label style={{marginRight: '5px', marginLeft: '10px'}}>Кількість</label>
                <input type={"number"} style={{width: '50px'}} {...fistCargoForm.register('count')}/>
    
                <label style={{marginRight: '5px', marginLeft: '10px'}}>Вартість</label>
                <input type={"number"} style={{width: '50px'}} {...fistCargoForm.register('cost')}/>
    
                <label style={{marginRight: '5px', marginLeft: '10px'}}>Вага</label>
                <input type={"number"} style={{width: '50px'}} {...fistCargoForm.register('weight')}/>
    
                <label style={{marginRight: '5px', marginLeft: '10px'}}>Довжина</label>
                <input type={"number"} style={{width: '50px'}} {...fistCargoForm.register('length')}/>
    
                <label style={{marginRight: '5px', marginLeft: '10px'}}>Ширина</label>
                <input type={"number"} style={{width: '50px'}} {...fistCargoForm.register('width')}/>
    
                <label style={{marginRight: '5px', marginLeft: '10px'}}>Висота</label>
                <input type={"number"} style={{width: '50px'}} {...fistCargoForm.register('height')}/>
    
                <p className={styles.error}>{
                  fistCargoForm.formState.errors.count?.message ||
                  fistCargoForm.formState.errors.cost?.message ||
                  fistCargoForm.formState.errors.weight?.message ||
                  fistCargoForm.formState.errors.length?.message ||
                  fistCargoForm.formState.errors.width?.message ||
                  fistCargoForm.formState.errors.height?.message
                }</p>
              </div>
  
              {isTwoPlaces &&
                <div style={{marginTop: '10px'}} className={styles.routeContainer}>
                  <label style={{marginRight: '5px', marginLeft: '10px'}}>Кількість</label>
                  <input type={"number"} style={{width: '50px'}} {...secondCargoForm.register('count')}/>
    
                  <label style={{marginRight: '5px', marginLeft: '10px'}}>Вартість</label>
                  <input type={"number"} style={{width: '50px'}} {...secondCargoForm.register('cost')}/>
    
                  <label style={{marginRight: '5px', marginLeft: '10px'}}>Вага</label>
                  <input type={"number"} style={{width: '50px'}} {...secondCargoForm.register('weight')}/>
    
                  <label style={{marginRight: '5px', marginLeft: '10px'}}>Довжина</label>
                  <input type={"number"} style={{width: '50px'}} {...secondCargoForm.register('length')}/>
    
                  <label style={{marginRight: '5px', marginLeft: '10px'}}>Ширина</label>
                  <input type={"number"} style={{width: '50px'}} {...secondCargoForm.register('width')}/>
    
                  <label style={{marginRight: '5px', marginLeft: '10px'}}>Висота</label>
                  <input type={"number"} style={{width: '50px'}} {...secondCargoForm.register('height')}/>
                  
                  <p className={styles.error}>{
                    secondCargoForm.formState.errors.count?.message ||
                    secondCargoForm.formState.errors.cost?.message ||
                    secondCargoForm.formState.errors.weight?.message ||
                    secondCargoForm.formState.errors.length?.message ||
                    secondCargoForm.formState.errors.width?.message ||
                    secondCargoForm.formState.errors.height?.message
                  }</p>
  
                  <a onClick={() => setIsTwoPlaces(false)} style={{color: 'red', marginLeft: '10px'}}>❌</a>
                </div>
              }
              
              <a onClick={() => setIsTwoPlaces(true)} className={styles.clear}>
                Додати місце
              </a>
            </div>
          }
          
          <div className={styles.routeContainer}>
            <p className={styles.name}>Послуга "Пакування"</p>
    
            <input style={{marginLeft: '12px'}} className={styles.checkbox} type={"checkbox"} {...mainForm.register("isPackaging")}/>
            <a style={{marginLeft: '20px', fontSize: '18px'}} target={"_blank"} className={styles.clear} href={"https://novaposhta.ua/uploads/misc/doc/Dodatkovi_poslygi.pdf"}>Тарифи пакування</a>
          </div>
  
          {mainForm.watch("isPackaging") &&
            <div>
              <div style={{marginTop: '10px'}} className={styles.routeContainer}>
                <label style={{marginLeft: '30px', marginRight: '5px'}}>Вид пакування</label>
                <select defaultValue={packagingTypes[0]} {...firstPackagingForm.register('typeOfPackaging')} style={{outline: 'none', width: '250px'}}>
                  {packagingTypes.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
  
                <label style={{marginLeft: '30px', marginRight: '5px'}}>Кількість</label>
                <input style={{width: '30px'}} {...firstPackagingForm.register('countPackaging')} value={1} disabled={true}/>
                
                <p className={styles.error}>{firstPackagingForm.formState.errors.typeOfPackaging?.message}</p>
              </div>
            </div>
          }
          
          <div className={styles.routeContainer}>
            <p className={styles.name}>Послуга "Підйом на поверх"</p>
    
            <label style={{marginLeft: '30px', marginRight: '5px'}}>поверх</label>
            <input className={styles.input} type={"number"} {...mainForm.register("floor")}/>
  
            <label style={{marginLeft: '30px', marginRight: '5px'}}>Ліфт</label>
            <input className={styles.checkbox} type={"checkbox"} {...mainForm.register("isLift")}/>
            
            <p className={styles.error}>{mainForm.formState.errors.floor?.message}</p>
          </div>
  
          <div className={styles.routeContainer}>
            <p className={styles.name}>Послуга "Зворотня доставка"</p>
            
            <input style={{marginLeft: '12px'}} className={styles.checkbox} type={"checkbox"} {...mainForm.register("isReverseDelivery")}/>
          </div>
  
          {mainForm.watch("isReverseDelivery")
            ? <div className={styles.routeContainer}>
              <p className={styles.name}>Вид зворотньої доставки</p>
    
              <select {...mainForm.register('reverseDelivery')} style={{outline: 'none', width: '150px', marginLeft: '30px'}}>
                <option value=""></option>
                {reverseDeliveries.map(c => <option key={c} value={c}>{c}</option>)}
              </select>
    
              <p className={styles.error}>{mainForm.formState.errors.reverseDelivery?.message}</p>
            </div>
            : mainForm.setValue('reverseDelivery', '')
          }
          
          {mainForm.watch("shipment") === shipments[0]
            ? <div className={styles.routeContainer}>
              <p className={styles.name}>Послуга палетування</p>
    
              <input style={{marginLeft: '12px'}} className={styles.checkbox} type={"checkbox"} {...mainForm.register("isPalletizing")}/>
            </div>
            : mainForm.setValue("isPalletizing", false)
          }
          
          <div className={styles.buttonsContainer}>
            <button className={styles.button} type={"submit"}>
              Розрахувати вартість
            </button>
            
            <a onClick={clear} className={styles.clear}>
              Очистити
            </a>
          </div>
        </form>
      </div>
  
      <button className={styles.button} style={{marginTop: '40px'}} onClick={() => navigate('/')}>To home</button>
    </div>
  );
};

export default Task02;